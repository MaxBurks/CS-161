#importing csv library
import csv

#var asking for name
name = input('what is your name: ')
#concatonation for name
print('Hello ' + name)

#turning var into an int. no data validation. an error will be given if done incorrectly
age = int(input('what is your age: '))
#error because it is trying to add a string to an integer
#concatonation adding 5 to var
print(age + 5)

#turning var into an int. no data validation. an error will be given if done incorrectly
added_age = int(input('how many years do you want to add to your age: '))



#concatonated print statement. f-strings would fit better, being able to skip formatting issues
print('In ' + str(added_age) + ' years you will be ' + str((age+added_age)) + ' years old.' )

#setting variables to check life expectancy dependant on being male or female
age_ref = -1
sex = input('are you M or F? ')

#opening lifesheet.cs
with open('lifesheet.csv') as csv_life:
    csv_timeline = csv.reader(csv_life)
    #iterating over each row checking if age in first row matches age input
    for row in csv_timeline:
        #using age_ref to be used as an int ref for age var
        try:
            age_ref = int(row[0])
        except ValueError:
            age_ref == -1
        #if sex is male then it will check row three
        if sex.upper() == 'M':
            if age_ref == age:
                death_date = float(row[3])
        #if sex is female then it will check row 6
        else:
            if age_ref == age:
                death_date = float(row[6])
#adding current year to time left to live
death_year = str(2025+int(death_date))
#printing estimate
print('your estimated death will take place in ' + str(death_date)  + ' years. It will be in the year ' + (death_year))

#float var for hours and wage
hours_worked = float(input('Enter the number of hours worked this week: '))
hourly_wage = float(input('Enter your hourly wage, without the $: '))

#turning hours and wage into weekly and annual pay (rough estimate)
gross_pay = hours_worked*hourly_wage
annual_pay = gross_pay*52

hourly_wage = hourly_wage*40*50

#setting a number to compare to when running percentages
percentage = 101
#opening csv table
with open('tax table.csv') as tax:
    csv_tax = csv.reader(tax)
    #iterating over each row
    for row in csv_tax:
        #checking to see if collomn 4 has a $ sign indicating a salary
        if '$' in row[3]:
            #if found a var is set while removing the $ and , to convert into a float
            # I couldn't think of a better way to do this when I wrote the program
            salary = float(row[3].replace(',','').replace('$',''))
            #checking if the hourly wage is smaller than the salary.
            #if it is then the tax % is checked to see if it will also fit
            if hourly_wage < salary:
                if percentage > int(row[0].replace('%','')):
                    percentage = (int(row[0].replace('%','')))
            #else statement is covering the last row since it has no numbers in the file.
            #this unfortunatly means that this program only works with this csv file
            else:
                percentage = 37
#printing the gross salary with tax deducted
print(f'your yearly gross income after taxes is {(1-percentage*.01)*hourly_wage}')

#printing said weekly and annual pay
print('Your gross pay this week is ' + str(gross_pay))
print('Your estimated annual gross pay is ' + str(annual_pay))
